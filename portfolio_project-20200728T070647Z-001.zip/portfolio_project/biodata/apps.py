from django.apps import AppConfig


class BiodataConfig(AppConfig):
    name = 'biodata'
