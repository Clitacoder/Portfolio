from django.urls import path
from . import views
urlpatterns=[
		path('',views.HomePage.as_view(),name='home'),
		path('about/',views.AboutPage.as_view(),name='about'),
		path('about/education/',views.EducationPage.as_view(), name='education'),
		path('about/education/contact',views.ContactPage.as_view(),name='contact'),
		]